void *multiplyMatrix(long int *matFinal);
//long int *multiplyMatrix(long int *matFinal);

void printMatrix(unsigned int lines, unsigned int columns, long int *mat);

void *multiply(void *param); 