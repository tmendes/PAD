void printMatrix(long int *mat, unsigned int lines, unsigned int columns, char *fileName);

long int *readMatrix(unsigned int lines, unsigned int columns, char *fileName);
