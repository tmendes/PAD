long int *readFile(char nameFile[30], int dim1, int dim2);
