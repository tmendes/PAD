long int *multiplyMatrix(unsigned int lines1, unsigned int columns1, long int *mat1, 
                                                 unsigned int lines2, unsigned int columns2, long int *mat2);

void *multiply(void *param); 