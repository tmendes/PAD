#!/bin/bash
# Script exemplo para submissao de jobs ao sistema de filas LoadLeveler
# Essa e uma versao para ambientes paralelos.
#
# Criado por Andre Leon S. Gradvohl, Dr.
# Ultima atualizacao: Ter Fev  2 09:36:56 BRST 2016
#
# Definindo o nome do Job
#@ job_name = job_aula_t210905
#
# Definindo arquivo de saida e arquivo de erros
#@ output = Saida_$(jobid).out
#@ error = Erro_$(jobid).err
#
# Definindo se deve ser notificado por email.
#  A notificacao pode ser always | error | start | never | complete
#@ notification = always
#
#  Informando o email do usuario (mude para seu e-mail)
#@ notify_user = t210905
#
# Definindo o nome da fila (paralela)
#@ class = FT077
#
# Definindo as caracteristicas do job paralelo
#@ job_type = parallel
#
#   Quantidade de nos
#@ node = 1
#   Quantidade de tarefas por no
#@ tasks_per_node = 8
#   Definindo a rede que sera usada. @ network.protocol = tipo_rede[,forma_de_uso][,modo]
#@ network.MPI = sn_single,shared,us
# @ data_limit  = 6.4gb
# @ stack_limit = 1.0gb,1.0gb
#
# Enfileirar agora
#@ queue 
# Coloque a seguir os comandos que serao executados no cluster.
echo "Diretorio local: $PWD. Inicio do job"

/usr/bin/poe ${PWD}/mMat 10 -infolevel 2 -procs 8
echo "Fim do job"
