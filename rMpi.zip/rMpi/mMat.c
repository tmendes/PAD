#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

/* IDENTIFICADORES DAS TAREFAS E MENSAGENS*/

#define MASTER 0             
#define FROM_MASTER 1        
#define FROM_WORKER 2        

struct timeval ini_ler_mtz1, end_ler_mtz1, ini_ler_mtz2, end_ler_mtz2, ini_ler_mtz3, end_ler_mtz3, ini_mult, end_mult, tv;
unsigned int l_mat1, c_mat1, l_mat2, c_mat2, l_mat3, c_mat3, nThr;
struct timeval marcaTempo(struct timeval tv, time_t currenttime, char buffer[30]){
  gettimeofday(&tv, NULL); 
  currenttime=tv.tv_sec;
  strftime(buffer,30,"%d-%m-%Y %T.",localtime(&currenttime)); 
  printf("%s%ld;", buffer, tv.tv_usec);
  return tv; 
}
void calculaTempo(struct timeval starttime, struct timeval entime){
  printf("%ld;", (entime.tv_sec * 1000000 + entime.tv_usec)-(starttime.tv_sec * 1000000 + starttime.tv_usec));
}

/* 
tarefas,                    numero de tarefas 
id_task,                    identificador da tarefa
ntaskwork,                  number of worker tasks 
tsk_source,                 tarefa de origem
tsk_dest,                   tarefa de tsk_destino
mtype,                      tipo da mensagem
rows,                       numero de linhas a serem enviadas
distrow, extra, sliceM,     media das linha, carga extra e slice da matriz 
i, j, n, rc;                auxiliares
*/

int main(argc,argv)
int argc;
char *argv[];
{
int   tarefas,           
   id_task,              
   ntaskwork,           
   tsk_source,               
   tsk_dest,                 
   mtype,                
   rows,                  
   distrow, extra, sliceM, 
   i, j, n, rc;           

   int     DIMENSAO                  = atoi( argv[1] );

double   
   a[DIMENSAO][DIMENSAO],           /* matrix A */
   b[DIMENSAO][DIMENSAO],           /* matrix B */
   d[DIMENSAO][DIMENSAO],           /* matrix D */
   result[DIMENSAO][DIMENSAO];      /* matrix de resultados */
MPI_Status status;

MPI_Init(&argc,&argv);
MPI_Comm_rank(MPI_COMM_WORLD,&id_task);
MPI_Comm_size(MPI_COMM_WORLD,&tarefas);
if (tarefas < 2 ) {
  printf("Checando quantas tarefas tem o programa. Aborta caso seja menor que 2\n");
  MPI_Abort(MPI_COMM_WORLD, rc);
  exit(1);
  }
ntaskwork = tarefas-1;

        char buffer[30];
        time_t curtime;

/* ESCREVENDO A TAREFA PRINCIPAL */
   if (id_task == MASTER)
   {
      /* Imprimindo cabeçalho padrão do relatório */
      printf("Tipo;dimensao;Tarefas;ini_leit_mat1;fim_leit_mat1;tmp_leit_mat1;ini_leit_mat2;fim_leit_mat2;tm_leit_mat2;ini_leit_mat3;fim_leit_mat3;tm_leit_mat3;ini_mult_mat;fim_mult_mat;tmp_mult;\n");
      printf("MPI;%d;%d;",DIMENSAO,tarefas);
      /*GERANDO MATRIZ1(A)*/
      ini_ler_mtz1    = marcaTempo(ini_ler_mtz1, curtime, buffer); 
      for (i=0; i<DIMENSAO; i++)
         for (j=0; j<DIMENSAO; j++)
            a[i][j]= 1;

      end_ler_mtz1    = marcaTempo(end_ler_mtz1, curtime, buffer); 
      calculaTempo(ini_ler_mtz1, end_ler_mtz1);

      /*GERANDO MATRIZ2(B)*/
      ini_ler_mtz2    = marcaTempo(ini_ler_mtz2, curtime, buffer);   
      for (i=0; i<DIMENSAO; i++)
         for (j=0; j<DIMENSAO; j++)
            b[i][j]= 2;
        end_ler_mtz2    = marcaTempo(end_ler_mtz2, curtime, buffer); 
        calculaTempo(ini_ler_mtz2, end_ler_mtz2);
      
      /*GERANDO MATRIZ3(D)*/
      ini_ler_mtz3    = marcaTempo(ini_ler_mtz3, curtime, buffer);         
      for (i=0; i<DIMENSAO; i++)
         for (j=0; j<DIMENSAO; j++)
            d[i][j]= 1;
        end_ler_mtz3    = marcaTempo(end_ler_mtz3, curtime, buffer); 
        calculaTempo(ini_ler_mtz3, end_ler_mtz3);

      /* MANDANDO OS DADOS */
      distrow = DIMENSAO/ntaskwork;
      extra = DIMENSAO%ntaskwork;
      sliceM = 0;
      mtype = FROM_MASTER;
      ini_mult                = marcaTempo(ini_mult, curtime, buffer); 
      for (tsk_dest=1; tsk_dest<=ntaskwork; tsk_dest++)
      {
         rows = (tsk_dest <= extra) ? distrow+1 : distrow;     

         MPI_Send(&sliceM        , 1                  , MPI_INT   , tsk_dest, mtype, MPI_COMM_WORLD);
         MPI_Send(&rows          , 1                  , MPI_INT   , tsk_dest, mtype, MPI_COMM_WORLD);
         MPI_Send(&a[sliceM][0]  , rows*DIMENSAO      , MPI_DOUBLE, tsk_dest, mtype, MPI_COMM_WORLD);
         MPI_Send(&b             , DIMENSAO*DIMENSAO  , MPI_DOUBLE, tsk_dest, mtype, MPI_COMM_WORLD);
         MPI_Send(&d             , DIMENSAO*DIMENSAO  , MPI_DOUBLE, tsk_dest, mtype, MPI_COMM_WORLD);  
         sliceM = sliceM + rows;
      }

      /* RECEBENDO OS RESULTADOS */
      mtype = FROM_WORKER;
      for (i=1; i<=ntaskwork; i++)
      {
         tsk_source = i;
         MPI_Recv(&sliceM        , 1                  , MPI_INT   , tsk_source, mtype, MPI_COMM_WORLD, &status);
         MPI_Recv(&rows          , 1                  , MPI_INT   , tsk_source, mtype, MPI_COMM_WORLD, &status);
         MPI_Recv(&result[sliceM][0]  , rows*DIMENSAO , MPI_DOUBLE, tsk_source, mtype, MPI_COMM_WORLD, &status);
      }

      end_mult                = marcaTempo(end_mult, curtime, buffer); 
      calculaTempo(ini_mult, end_mult);
   }

/**** TAREFAS QUE MULTIPLICAM ****/
   if (id_task > MASTER)
   {
      mtype = FROM_MASTER;
      MPI_Recv(&sliceM  ,      1                  ,    MPI_INT, MASTER, mtype, MPI_COMM_WORLD, &status);
      MPI_Recv(&rows    ,      1                  ,    MPI_INT, MASTER, mtype, MPI_COMM_WORLD, &status);
      MPI_Recv(&a       ,      rows*DIMENSAO      , MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);
      MPI_Recv(&b       ,      DIMENSAO*DIMENSAO  , MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);
      MPI_Recv(&d       ,      DIMENSAO*DIMENSAO  , MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);

      for (n=0; k<DIMENSAO; n++)
         for (i=0; i<rows; i++)
         {
            result[i][n] = 0.0;
            for (j=0; j<DIMENSAO; j++)
               result[i][n] = result[i][n] + a[i][j] * b[j][n];
         }

         for (i=0; i<rows; i++)
         {
            for (j=0; j<DIMENSAO; j++)
               result[i][j] = result[i][j] + d[i][j];
         }
  
      mtype = FROM_WORKER;
      MPI_Send(&sliceM  , 1             , MPI_INT   , MASTER, mtype, MPI_COMM_WORLD);
      MPI_Send(&rows    , 1             , MPI_INT   , MASTER, mtype, MPI_COMM_WORLD);
      MPI_Send(&result  , rows*DIMENSAO , MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD);
   }
   MPI_Finalize();
}