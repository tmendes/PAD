mpcc -q64 -qarch=pwr7 -qtune=pwr7 -lm  mpi_gather.c -o mMat

xlc mMatSerial.c readFiles.c
mv a.out mMatSerial


