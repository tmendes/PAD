long int *multiplyMatrix(unsigned int lines1, unsigned int columns1, long int *mat1, 
                                                 unsigned int lines2, unsigned int columns2, long int *mat2,
                         unsigned int lines3, unsigned int columns3, long int *mat3);

void *multiply(void *param); 